
package pkg09022003;


public class NewClas {
    int a = 5;
    int b = 15;
    int aux = a;
    a = b;
    b = aux;
    System.out.println(aux);       
    
            
            
}
