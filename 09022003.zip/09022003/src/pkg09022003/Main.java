
package pkg09022003;


public class Main {

  
    public static void main(String[] args) {
        int f = 71;
        int c = (f - 32) * 5/9 ;        
        System.out.println(c);
        
        
    int a = 5;
    int b = 15;
    int aux = a;
    a = b;
    b = aux;
    System.out.println(aux); 
        
    }
    
}
